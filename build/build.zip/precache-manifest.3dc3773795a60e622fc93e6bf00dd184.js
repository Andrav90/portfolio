self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "42b76459f9e1bd1d8be3071773cc6dda",
    "url": "/index.html"
  },
  {
    "revision": "060d04eccff7cf8f026c",
    "url": "/static/css/main.7e3071dd.chunk.css"
  },
  {
    "revision": "730d2f08f3cebed69436",
    "url": "/static/js/2.353c3870.chunk.js"
  },
  {
    "revision": "9634438dd5c2c8da6f93dc19e1b2c1bc",
    "url": "/static/js/2.353c3870.chunk.js.LICENSE.txt"
  },
  {
    "revision": "060d04eccff7cf8f026c",
    "url": "/static/js/main.2b28e1a1.chunk.js"
  },
  {
    "revision": "4f2b1704eab49d50853b",
    "url": "/static/js/runtime-main.19ccc7f6.js"
  },
  {
    "revision": "f7f97fb4d465eeeb8e101be92d001fe7",
    "url": "/static/media/Andra_Vraciu_CV.f7f97fb4.pdf"
  },
  {
    "revision": "3ff965b647aa21770daa17bfaac79fd8",
    "url": "/static/media/bootstrap.3ff965b6.svg"
  },
  {
    "revision": "606a9fc12f02b6805d10f13eaac4d23e",
    "url": "/static/media/checkmark.606a9fc1.svg"
  },
  {
    "revision": "ae427edb9414023b7458031f6c5b5bb5",
    "url": "/static/media/down-arrow.ae427edb.svg"
  },
  {
    "revision": "6caacd1ac451f5d5c012ebabcb25d071",
    "url": "/static/media/firebase.6caacd1a.svg"
  },
  {
    "revision": "192a6620a687a9e7e51c0037973a1547",
    "url": "/static/media/github.192a6620.svg"
  },
  {
    "revision": "e243466fb60d6e72c587d224399a1a70",
    "url": "/static/media/global.e243466f.svg"
  },
  {
    "revision": "6c8e140e0c8b5d6acd513c67d12d267d",
    "url": "/static/media/linkedin2.6c8e140e.svg"
  },
  {
    "revision": "bb1a8e90dfd6f039f9829563ffff0205",
    "url": "/static/media/myPicture.bb1a8e90.png"
  },
  {
    "revision": "b644559d6843fb7fb015c861a6fb025d",
    "url": "/static/media/project1.b644559d.PNG"
  },
  {
    "revision": "655b519c6aa1d4f9f8d8024d84491a74",
    "url": "/static/media/project2.655b519c.PNG"
  },
  {
    "revision": "74db70337ee79cd75a42c319ab4dc905",
    "url": "/static/media/project3.74db7033.PNG"
  },
  {
    "revision": "024196716802e272adb3cbefb81fd557",
    "url": "/static/media/react-router.02419671.svg"
  },
  {
    "revision": "7038477259b6f1696308f867ce8c0a3a",
    "url": "/static/media/react.70384772.svg"
  },
  {
    "revision": "85772647236e76b8e772c14c092a28ac",
    "url": "/static/media/redux.85772647.svg"
  },
  {
    "revision": "1603865df2518b8aab6c0b33af9ca9a2",
    "url": "/static/media/x-mark.1603865d.svg"
  }
]);