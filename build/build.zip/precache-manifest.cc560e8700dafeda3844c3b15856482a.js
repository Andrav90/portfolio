self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "99562445689acc4cb6750b19ee1256ae",
    "url": "/index.html"
  },
  {
    "revision": "a37ed677197c853d01da",
    "url": "/static/css/main.61eeb865.chunk.css"
  },
  {
    "revision": "6b1e688198cba279719e",
    "url": "/static/js/2.86b2cdd2.chunk.js"
  },
  {
    "revision": "a3665d6c225620e8f1eea625deccc493",
    "url": "/static/js/2.86b2cdd2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a37ed677197c853d01da",
    "url": "/static/js/main.d9db8f0a.chunk.js"
  },
  {
    "revision": "4f2b1704eab49d50853b",
    "url": "/static/js/runtime-main.19ccc7f6.js"
  },
  {
    "revision": "f7f97fb4d465eeeb8e101be92d001fe7",
    "url": "/static/media/Andra_Vraciu_CV.f7f97fb4.pdf"
  },
  {
    "revision": "021b9945a4e4e39ac7e7e6b95afc573b",
    "url": "/static/media/bootstrap.021b9945.svg"
  },
  {
    "revision": "606a9fc12f02b6805d10f13eaac4d23e",
    "url": "/static/media/checkmark.606a9fc1.svg"
  },
  {
    "revision": "ae427edb9414023b7458031f6c5b5bb5",
    "url": "/static/media/down-arrow.ae427edb.svg"
  },
  {
    "revision": "04df79aafb6fe943f093739ce261d608",
    "url": "/static/media/firebase.04df79aa.svg"
  },
  {
    "revision": "192a6620a687a9e7e51c0037973a1547",
    "url": "/static/media/github.192a6620.svg"
  },
  {
    "revision": "6c8e140e0c8b5d6acd513c67d12d267d",
    "url": "/static/media/linkedin.6c8e140e.svg"
  },
  {
    "revision": "5d21077bcbb37b24e230aa1ce98bf9a3",
    "url": "/static/media/mail-sent.5d21077b.svg"
  },
  {
    "revision": "4b509f23602a7f863c285925170e05af",
    "url": "/static/media/me.4b509f23.jpg"
  },
  {
    "revision": "b644559d6843fb7fb015c861a6fb025d",
    "url": "/static/media/project1.b644559d.PNG"
  },
  {
    "revision": "655b519c6aa1d4f9f8d8024d84491a74",
    "url": "/static/media/project2.655b519c.PNG"
  },
  {
    "revision": "74db70337ee79cd75a42c319ab4dc905",
    "url": "/static/media/project3.74db7033.PNG"
  },
  {
    "revision": "ca2ad3531e77fd0b8c65a6d836651e51",
    "url": "/static/media/project4.ca2ad353.PNG"
  },
  {
    "revision": "ccd47f9a75037fd1e4eeca7fb3ded2c9",
    "url": "/static/media/project5.ccd47f9a.PNG"
  },
  {
    "revision": "024196716802e272adb3cbefb81fd557",
    "url": "/static/media/react-router.02419671.svg"
  },
  {
    "revision": "7038477259b6f1696308f867ce8c0a3a",
    "url": "/static/media/react.70384772.svg"
  },
  {
    "revision": "8db5010752a9c3fe4f5092387dcf73ae",
    "url": "/static/media/redux.8db50107.svg"
  },
  {
    "revision": "e243466fb60d6e72c587d224399a1a70",
    "url": "/static/media/web.e243466f.svg"
  },
  {
    "revision": "1603865df2518b8aab6c0b33af9ca9a2",
    "url": "/static/media/x-mark.1603865d.svg"
  }
]);